package SDA;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
        NewJFrame njf = new NewJFrame();
        njf.show();
    }
}


