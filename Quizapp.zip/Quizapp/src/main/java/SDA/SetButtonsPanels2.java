package SDA;

public class SetButtonsPanels2 extends NewJFrame
{
    public void setButtons ()
    {
//        getjButton3().setEnabled(true);
//        getjButton3().setVisible(true);
//
//        getjButton4().setEnabled(true);
//        getjButton5().setEnabled(true);
//        getjButton6().setEnabled(true);
    }


}
